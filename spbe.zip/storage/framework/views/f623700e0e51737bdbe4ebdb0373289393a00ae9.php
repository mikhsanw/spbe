<footer class="main-footer">
	  <div class="container">
		 <?php echo e(date('Y')); ?> © <a href="#"><?php echo e($aplikasi->singkatan); ?></a>. Tim IT Diskominfotik Kabupaten Bengkalis
	  </div>
  </footer><?php /**PATH D:\laragon\www\spbe\resources\views/layouts/backend/footer.blade.php ENDPATH**/ ?>

<?php $__env->startPush('header', ($menu->nama ?? 'ERROR')); ?>
<?php $__env->startSection('content'); ?>
<section class="error-page h-p100">
    <div class="container h-p100">
        <div class="row h-p100 align-items-center justify-content-center text-center">
            <div class="col-lg-7 col-md-10 col-12">
                <div class="rounded30 p-50">
                    <img src="<?php echo e(url('images/auth-bg/404.jpg')); ?>" class="max-w-200" alt="" />
                    <h1><?php echo e(($menu->nama ?? 'ERROR')); ?> !</h1>
                    <h3>Mohon maaf, Halaman tidak ditemukan.</h3>
                    <div class="my-30"><a href="<?php echo e(url('/home')); ?>" class="btn btn-danger">Back to dashboard</a></div>				  
                </div>
            </div>				
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\new-master\resources\views/errors/404.blade.php ENDPATH**/ ?>
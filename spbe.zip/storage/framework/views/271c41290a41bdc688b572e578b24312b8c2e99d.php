$(document).ready(function() {
	$('#datatable').DataTable({
		responsive: true,
		serverside: true,
		lengthChange: true,
		language: {
            url: "<?php echo e(asset('resources/vendor/datatables/js/indonesian.json')); ?>"
        },
		processing: true,
		serverSide: true,
		ajax: "<?php echo e(url($url_admin.'/'.$kode.'/data/'.$id)); ?>",
		columns: [
                { data: 'DT_RowIndex', name: 'DT_RowIndex', orderable: false, searchable: false },
				{ data: 'nama' },
				{ data: 'kelola'},
				{ data: 'action', orderable: false, searchable: false}
		    ]
    });
});
<?php /**PATH D:\laragon\www\spbe\resources\views/backend/halaman/datatables_detail.blade.php ENDPATH**/ ?>
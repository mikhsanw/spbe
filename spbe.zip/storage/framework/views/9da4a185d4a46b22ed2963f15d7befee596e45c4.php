$(document).ready(function () {
	$('.select2').select2(
		{
			placeholder: "- Pilih -",
			allowClear: true
		}
	);

	var controls = {
        leftArrow: '<i class="fal fa-angle-left" style="font-size: 1.25rem"></i>',
        rightArrow: '<i class="fal fa-angle-right" style="font-size: 1.25rem"></i>'
    }
})<?php /**PATH D:\laragon\www\master\resources\views/backend/kontak/ajax.blade.php ENDPATH**/ ?>
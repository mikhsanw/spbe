
<?php $__env->startSection('title', $data->nama); ?>
<?php $__env->startSection('img', asset($aplikasi->file_logo->url_stream)); ?>
<?php $__env->startSection('content'); ?>
<section class="page-title title-bg22">
    <div class="d-table">
        <div class="d-table-cell">
            <h2><?php echo e($data->nama); ?></h2>
            <ul>
                <li>
                    <a href="<?php echo e(url('/')); ?>">Beranda</a>
                </li>
                <?php if($data->parentRecursive): ?>
                <?php echo $data->createMenuTree($data->parentRecursive); ?>

                <li><?php echo e($data->nama); ?></li>
                <?php else: ?>
                <li><?php echo e($data->nama); ?></li>

                <?php endif; ?>
            </ul>
        </div>
    </div>
    <div class="lines">
        <div class="line"></div>
        <div class="line"></div>
        <div class="line"></div>
    </div>
</section>

<?php if($data->status==4): ?>
<section class="categories-section faq-section pt-5 pb-70">
    <div class="container">
        <div class="row">
            <?php $__currentLoopData = $data->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($item->status=='1'): ?>
            <div class="col-lg-12">
                <div class="accordions">
                    <div class="accordion-item">
                        <div class="accordion-title" data-tab="item1">
                            <h2><?php echo e($item->nama); ?><i class="bx bx-chevrons-right down-arrow"></i></h2>
                        </div>
                        <div class="accordion-content" id="item1" style="display: none;">
                            <div class="row">
                                <?php $__currentLoopData = $item->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-lg-3 col-sm-6">
                                    <a href="<?php echo e($val->status==2?$val->link:url('/company/page/'.$val->id.'/'.Help::generateSeoURL($val->nama))); ?>">
                                        <div class="category-item">
                                            <i class="flaticon-wrench-and-screwdriver-in-cross"></i>
                                            <h3><?php echo e($val->nama); ?></h3>
                                            <p><?php echo e($item->nama); ?></p>
                                        </div>
                                    </a>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php else: ?>
            <div class="col-lg-3 col-md-4 col-sm-6">
                <a href="<?php echo e($item->status==2?$item->link:url('/company/page/'.$item->id.'/'.Help::generateSeoURL($item->nama))); ?>">
                    <div class="category-card">
                        <?php if($item->file): ?>
                        <img src="<?php echo e($item->file_logo->url_stream); ?>" width="60px" alt="$item->nama">
                        <?php else: ?>
                        <i class='flaticon-website'></i>
                        <?php endif; ?>
                        <h3><?php echo e($item->nama); ?></h3>
                        <!-- <p>301 open position</p> -->
                    </div>
                </a>
            </div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>

<?php else: ?>

<section class="contact-form-section pt-5 pb-70">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-12 col-md-10">
                <?php if($data->status==0): ?>
                <p><?php echo $data->isi; ?></p>
                <?php elseif($data->status==3): ?>
                <div class="list-group">
                    <?php $__currentLoopData = $doc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dokumen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($dokumen->getExtensionAttribute()==="pdf"): ?>
                    <a href="#" class="list-group-item list-group-item-action dokumen" data-bs-toggle="modal"
                        data-bs-target="#dokumen-modal-lg" data-bs-title="<?php echo e($dokumen->name); ?>"
                        data-bs-whatever="<?php echo e($dokumen->url_stream); ?>">
                        <?php echo e($dokumen->name); ?>

                        <i class="i-plain icon-download float-end dokumen" data-bs-toggle="modal"
                            data-bs-target="#dokumen-modal-lg" data-bs-title="<?php echo e($dokumen->name); ?>"
                            data-bs-whatever="<?php echo e($dokumen->url_stream); ?>"></i>
                    </a>
                    <?php else: ?>
                    <a href="<?php echo e($dokumen->url_download); ?>"
                        download="<?php echo e($dokumen->name.'.'.$dokumen->getExtensionAttribute()); ?>"
                        class="list-group-item list-group-item-action">
                        <?php echo e($dokumen->name); ?>

                        <i class="i-plain icon-download float-end"></i>
                    </a>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php elseif($data->status==5): ?>
                <?php if($data->file): ?>
                <?php if($data->file->extension=='pdf'): ?>
                <object data="<?php echo e($data->file->url_stream.'?t='.time() ?? '#'); ?>" type="application/pdf"
                    style="background: transparent url('backend/img/loading.gif') no-repeat center; width: 100%;height: 700px">
                    <p>
                        File PDF tidak dapat ditampilkan, silahkan download file
                        <a download="<?php echo e($data->nama); ?>" href="<?php echo e($data->file->url_stream ?? '#'); ?>" target="_blank">
                            <span class="fa fa-download"> di sini</span>
                        </a>
                    </p>
                </object>
                <?php elseif($data->file->extension=='jpg' || $data->file->extension=='png'): ?>
                <p>
                    <img src="<?php echo e($data->file->url_stream.'?t='.time() ?? '#'); ?>" />
                </p>
                <?php else: ?>
                <p>
                    File tidak dapat ditampilkan, silahkan download file
                    <a download="<?php echo e($data->nama); ?>" href="<?php echo e($data->file->url_download.'?t='.time() ?? '#'); ?>" target="_blank">
                        <span class="fa fa-download"> di sini</span>
                    </a>
                </p>
                <?php endif; ?>
                <?php endif; ?>
                <?php elseif($data->status==4): ?>
                <div class="row">
                    <?php $__currentLoopData = $data->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($item->children->count()>0): ?>
                    portal kategori
                    <?php else: ?>
                    <div class="col-md-3">
                        <?php echo e($item->nama); ?>

                    </div>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section><!-- #content end -->
<?php endif; ?>

<div class="modal fade" id="dokumen-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title" id="myModalLabel">Modal</h4>
                <button type="button" class="btn-close btn-sm" data-bs-dismiss="modal" aria-hidden="true"></button>
            </div>
            <div class="modal-body">
                <iframe width="100%" height="600px"></iframe>
            </div>
        </div>
    </div>
</div>

<script>
    var modalShow = document.getElementById('dokumen-modal-lg')
    modalShow.addEventListener('show.bs.modal', function (event) {
        var button = event.relatedTarget
        var recipient = button.getAttribute('data-bs-whatever')
        var title = button.getAttribute('data-bs-title')
        var modalTitle = modalShow.querySelector('.modal-title')
        modalTitle.textContent = 'Dokumen ' + title
        var makeIframe = modalShow.querySelector(".modal-body iframe");
        makeIframe.setAttribute("src", recipient);
    })

</script>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('css'); ?>
<style>
    .line {
        margin-top: 1rem;
        margin-bottom: 1rem;
        border: 0;
        border-top: 1px solid rgba(0, 0, 0, 0.1);
    }

    .category-card img {
        font-size: 50px;
        color: #fd1616;
        margin-bottom: 25px;
        display: inline-block;
        line-height: 1;
    }
</style>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.frontend.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\spbe\resources\views/frontend/beranda/halaman.blade.php ENDPATH**/ ?>
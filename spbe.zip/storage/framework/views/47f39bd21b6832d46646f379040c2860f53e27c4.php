
<?php $__env->startSection('title', 'Galeri '.$jenis); ?>
<?php $__env->startSection('img', asset($aplikasi->file_logo->url_stream)); ?>
<?php $__env->startSection('content'); ?>
<section class="page-title title-bg22">
    <div class="d-table">
        <div class="d-table-cell">
            <h2>Galeri <?php echo e($jenis); ?></h2>
            <ul>
                <li>
                    <a href="<?php echo e(url('/')); ?>">Beranda</a>
                </li>
                <li>Galeri</li>
                <li><?php echo e($jenis); ?></li>
            </ul>
        </div>
    </div>
    <div class="lines">
        <div class="line"></div>
        <div class="line"></div>
        <div class="line"></div>
    </div>
</section>

<div class="contact-form-section pt-5 pb-70 lightbox-gallery">
    <div class="container">
        <div class="intro">
            <!-- <h2 class="text-center">Galeri <?php echo e($jenis); ?></h2> -->
        </div>
        <div class="row photos">
			<?php if($jenis==='foto'): ?>
			<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-sm-6 col-md-4 col-lg-3 item">
				<a href="<?php echo e($foto->file->url_stream); ?>" data-caption="<?php echo e($foto->nama); ?>" data-toggle="lightbox" data-gallery="example-gallery">
					<img class="img-fluid" src="<?php echo e($foto->file->url_stream); ?>"></a>
			</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php elseif($jenis==='video'): ?>
			<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="col-sm-6 col-md-4 col-lg-3 item">
				<a href="//www.youtube.com/embed/<?php echo e($video->link); ?>" data-toggle="lightbox" data-gallery="youtubevideos">
					<img src="https://i1.ytimg.com/vi/<?php echo e($video->link); ?>/mqdefault.jpg" class="img-fluid">
				</a>
			</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php endif; ?>
         </div>
    </div>
</div>
<div style="text-align: center;"><?php echo e($data->links()); ?> </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script src="<?php echo e(url('/frontend/assets/js/bs5-lightbox/index.bundle.min.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.frontend.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\spbe\resources\views/frontend/beranda/galeri.blade.php ENDPATH**/ ?>

<?php $__env->startSection('title', 'Beranda'); ?>
<?php $__env->startSection('img', ($aplikasi->file_logo?(asset($aplikasi->file_logo->url_stream)):'')); ?>
<?php $__env->startSection('content'); ?>
		<section id="slider" class="slider-element boxed-slider">
			<div class="fslider">
				<div class="flexslider">
					<div class="slider-wrap">
					<?php $__currentLoopData = $slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="slide">
							<a href="#" class="d-block position-relative">
								<img src="<?php echo e($data->file->url_stream); ?>')" alt="Slide 2">
							</a>
						</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
				</div>
			</div>
		</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\new-master\resources\views/frontend/beranda/index.blade.php ENDPATH**/ ?>
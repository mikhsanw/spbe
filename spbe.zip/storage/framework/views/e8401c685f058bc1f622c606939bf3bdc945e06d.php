$(document).on("click",".tambah-halaman",function() {
    ojisatrianiLoadingFadeIn();
    $.loadmodal({
        url: "<?php echo e(url($url_admin.'/'.$kode.'/create_child/'.$id)); ?>",
        id: 'responsive',
        dlgClass: 'fade',
        bgClass: 'primary',
        title: 'Simpan',
        width: 'whatever',
        modal: {
            keyboard: true,
            },
        ajax: {
            dataType: 'html',
            method: 'GET',
            success: function(data, status, xhr){
                $('.submit-surat').hide();
                ojisatrianiLoadingFadeOut();
            },
        },
    });
});<?php /**PATH D:\laragon\www\spbe\resources\views/backend/halaman/jquery-detail.blade.php ENDPATH**/ ?>
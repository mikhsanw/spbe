
<?php $__env->startPush('header', ($menu->nama ?? 'Tidak ada akses')); ?>
<?php $__env->startSection('content'); ?>
<div class="h-alt-hf d-flex flex-column align-items-center justify-content-center text-center">
    <h1 class="page-error color-fusion-500">
        <span class="text-gradient"> <Em>ERROR 403</Em> </span>
    </h1>
    <h3 class="fw-500 mb-5">
        Mohon maaf, anda tidak ada akses untuk mengunjungi halaman ini.
    </h3>
    <div class="my-30"><a href="<?php echo e(url('/home')); ?>" class="btn btn-danger">Back to dashboard</a></div>				  

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\new-master\resources\views/layouts/backend/error/403.blade.php ENDPATH**/ ?>
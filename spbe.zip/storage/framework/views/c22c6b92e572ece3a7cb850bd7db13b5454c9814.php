$(document).on("click",".create",function() {
    ojisatrianiLoadingFadeIn();
    var id = $(this).attr("<?php echo e($kode.'-id'); ?>");
    $.loadmodal({
        url: "<?php echo e(url($url_admin.'/'.$kode)); ?>/save/"+ id,
    id: 'responsive',
        dlgClass: 'fade',
        bgClass: 'warning',
        title: 'Ubah',
        width: 'whatever',
        modal: {
            keyboard: true,
            // any other options from the regular $().modal call (see Bootstrap docs)
            },
        ajax: {
            dataType: 'html',
            method: 'GET',
            success: function(data, status, xhr){
                $('.modal-footer').remove();
                ojisatrianiLoadingFadeOut();
            },
        },
    });
});

$(document).on("click",".link",function() {
    ojisatrianiLoadingFadeIn();
    var id = $(this).attr("<?php echo e($kode.'-id'); ?>");
    $.loadmodal({
        url: "<?php echo e(url($url_admin.'/'.$kode)); ?>/link/"+ id,
    id: 'responsive',
        dlgClass: 'fade',
        bgClass: 'warning',
        title: 'Ubah',
        width: 'whatever',
        modal: {
            keyboard: true,
            // any other options from the regular $().modal call (see Bootstrap docs)
            },
        ajax: {
            dataType: 'html',
            method: 'GET',
            success: function(data, status, xhr){
                $('.modal-footer').remove();
                ojisatrianiLoadingFadeOut();
            },
        },
    });
});

$(document).on("click",".upload",function() {
    ojisatrianiLoadingFadeIn();
    var id = $(this).attr("<?php echo e($kode.'-id'); ?>");
    $.loadmodal({
        url: "<?php echo e(url($url_admin.'/'.$kode)); ?>/upload/"+ id,
    id: 'responsive',
        dlgClass: 'fade',
        bgClass: 'warning',
        title: 'Ubah',
        width: 'whatever',
        modal: {
            keyboard: true,
            // any other options from the regular $().modal call (see Bootstrap docs)
            },
        ajax: {
            dataType: 'html',
            method: 'GET',
            success: function(data, status, xhr){
                $('.modal-footer').remove();
                ojisatrianiLoadingFadeOut();
            },
        },
    });
});<?php /**PATH D:\laragon\www\new-master\resources\views/backend/halaman/jquery.blade.php ENDPATH**/ ?>
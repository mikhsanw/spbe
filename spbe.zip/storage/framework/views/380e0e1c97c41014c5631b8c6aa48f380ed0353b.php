<?php if(empty($mega)): ?>
<li class="menu-item">
    <?php if($data->children->count() > 0): ?>
    <a class="menu-link" href="<?php echo e(url('#')); ?>"><div><?php echo e($data->nama); ?></div></a>
    <ul class="sub-menu-container" style="min-width: max-content">
        <?php $__currentLoopData = $data->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $__env->make('layouts.frontend.menu', ['data'=>$sub], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <?php else: ?>
        <?php if($data->status==2): ?>
        <a class="menu-link" href="<?php echo e($data->link); ?>"><div><?php echo e($data->nama); ?></div></a>
        <?php else: ?>
        <a class="menu-link" href="<?php echo e(url('/company/page/'.$data->id.'/'.Help::generateSeoURL($data->nama))); ?>"><div><?php echo e($data->nama); ?></div></a>
        <?php endif; ?>

    <?php endif; ?>
</li>
<?php else: ?>
<li class="menu-item mega-menu mega-menu-small">
    <a class="menu-link" href="#"><div><?php echo e($data->nama); ?></div></a>
    <div class="mega-menu-content" style="width: max-content">
        <div class="row mx-0">
            <?php $i=1; ?>
            <?php $__currentLoopData = $data->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($i==1): ?>
                <ul class="sub-menu-container mega-menu-column col" style="min-width: fit-content">
                    <li class="menu-item">
                        <?php if($sub->status==2): ?>
                            <a class="menu-link" href="<?php echo e($sub->link); ?>"><div><?php echo e($sub->nama); ?></div></a>
                        <?php else: ?>
                            <a class="menu-link" href="<?php echo e(url('/company/page/'.$sub->id.'/'.Help::generateSeoURL($sub->nama))); ?>"><div><?php echo e($sub->nama); ?></div></a>
                        <?php endif; ?>
                    </li>
                <?php elseif($i==2): ?>
                    <li class="menu-item">
                        <?php if($sub->status==2): ?>
                            <a class="menu-link" href="<?php echo e($sub->link); ?>"><div><?php echo e($sub->nama); ?></div></a>
                        <?php else: ?>
                            <a class="menu-link" href="<?php echo e(url('/company/page/'.$sub->id.'/'.Help::generateSeoURL($sub->nama))); ?>"><div><?php echo e($sub->nama); ?></div></a>
                        <?php endif; ?>
                    </li>
                <?php elseif($i==3): ?>
                    <li class="menu-item">
                        <?php if($sub->status==2): ?>
                            <a class="menu-link" href="<?php echo e($sub->link); ?>"><div><?php echo e($sub->nama); ?></div></a>
                        <?php else: ?>
                            <a class="menu-link" href="<?php echo e(url('/company/page/'.$sub->id.'/'.Help::generateSeoURL($sub->nama))); ?>"><div><?php echo e($sub->nama); ?></div></a>
                        <?php endif; ?>
                    </li>
                </ul>
                <?php endif; ?>
                <?php $i++ ?>
                <?php if($i>3) $i=1; ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</li>
<?php endif; ?><?php /**PATH D:\laragon\www\new-master\resources\views/layouts/frontend/menu.blade.php ENDPATH**/ ?>
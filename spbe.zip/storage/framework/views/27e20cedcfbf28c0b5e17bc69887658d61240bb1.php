
<?php $__env->startPush('title', $halaman->nama); ?>
<?php $__env->startPush('header',$halaman->nama); ?>
<?php $__env->startPush('tombol'); ?>
<a class="waves-effect waves-light btn bg-gradient-primary py-2 px-3 b-0 tambah" href="#tambah">
    Tambah
</a>
<a class="waves-effect waves-light btn bg-gradient-warning py-2 px-3 b-0" href="<?php echo e(url($halaman->kode.'/extract-menu')); ?>" target="_blank">
    Extract Menu
</a>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <div class="panel-container show">
        <div class="panel-content">
            <?php echo Form::open(array('id' => 'frmDepan', 'route' => ['menu.susun-menu'], 'class' => 'form account-form', 'method' => 'post', 'files' => 'true')); ?>

            <div class="alert alert-info fade show mb-0" role="alert">
                <div class="d-flex align-items-center">
                    <div class="alert-icon width-3">
                      <span class="icon-stack icon-stack-sm">
                          <i class="ni ni-list color-success-800 icon-stack-2x font-weight-bold"></i>
                      </span>
                    </div>
                    <div class="flex-1">
                        <span class="h5 m-0 fw-700">List menu <?php echo config('master.aplikasi.singkatan'); ?> !</span>
                        Susun menu dengan benar.
                    </div>
                </div>
            </div>
            <div class="col col-md-12 col-xl-12 ">
                <div class="panel-tag">
                    <p class="loading text-center" style="display: none">
                        <button class="btn btn-outline-dark rounded-pill waves-effect waves-themed text-center" type="button" disabled="">
                            <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                            Loading...
                        </button>
                    </p>
                    <div class="table-responsive">
                        <div class="dd" id="nestable" style="width: fit-content; min-width: 100%;">
                            <div class="list">
                                
                            </div>
                            <p>
                                <?php echo Form::hidden('urutkan', NULL, array('id' => 'nestable-output', 'class' => 'form-control', 'placeholder' => 'nestable-output','readonly'=>'readonly')); ?>

                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="alert alert-secondary alert-dismissible fade show" role="alert">
                <div class="d-flex align-items-center">
                    <div class="flex-1">
                        <button type="submit" class="btn btn-sm btn-primary"><i class="fa fa-save"></i> Simpan
                        </button>
                    </div>
                </div>
            </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <script type="text/javascript" src="<?php echo e(URL::asset(config('master.aplikasi.author').'/'.$halaman->kode.'/datatables.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(URL::asset(config('master.aplikasi.author').'/'.$halaman->kode.'/jquery.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('backend/assets/vendor_components/nestable/jquery.nestable.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('backend/main/js/pages/nestable.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/assets/vendor_components/select2/dist/js/select2.full.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" media="screen, print" href="<?php echo e(asset('backend/fromplugin/summernote/summernote.css')); ?>">
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.backend.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\master\resources\views/backend/menu/index.blade.php ENDPATH**/ ?>
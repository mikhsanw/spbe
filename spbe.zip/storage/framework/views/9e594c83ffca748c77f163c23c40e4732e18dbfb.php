<li class="nav-item">
    <?php if($data->children->count() > 0 && $data->status != 4): ?>
    <a class="nav-link" href="<?php echo e(url('#')); ?>"><?php echo e($data->nama); ?></a>
    <ul class="dropdown-menu">
        <?php $__currentLoopData = $data->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $__env->make('layouts.frontend.menu', ['data'=>$sub], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <?php else: ?>
        <?php if($data->status==2): ?>
        <a class="nav-link" href="<?php echo e($data->link); ?>"><?php echo e($data->nama); ?></a>
        <?php else: ?>
        <a class="nav-link" href="<?php echo e(url('/company/page/'.$data->id.'/'.Help::generateSeoURL($data->nama))); ?>"><?php echo e($data->nama); ?></a>
        <?php endif; ?>

    <?php endif; ?>
</li><?php /**PATH D:\laragon\www\spbe\resources\views/layouts/frontend/menu.blade.php ENDPATH**/ ?>

<?php $__env->startPush('title','Ubah Password'); ?>
<?php $__env->startPush('header','Ubah Password'); ?>
<?php $__env->startSection('content'); ?>
<div class="panel-container show">
	<div class="panel-content">
		<div class="gantipwd">
			<form>
				<div class="form-group">
					<label for="password_lama">Password Lama</label>
					<input type="password" name="password_lama" class="form-control" id="password_lama" placeholder="Password Lama">
				</div>
				<div class="form-group">
					<label for="password">Password Baru</label>
					<input type="password" name="password" class="form-control" id="password" placeholder="Password Baru">
				</div>
				<div class="form-group">
					<label for="password_confirmation">Ketik ulang password</label>
					<input type="password" name="password_confirmation" class="form-control" id="password_confirmation" placeholder="Ketik ulang password">
				</div>
				<input type="hidden" value="<?php echo e($user->id); ?>" name="id" class="form-control" id="id">
		      <button type="button" onclick="ubahPassword()" class="btn btn-primary">Ubah</button>
	      	</form>
      </div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script src="<?php echo e(URL::asset('resources/vendor/jquery/jquery.enc.js')); ?>"></script>
<script src="<?php echo e(URL::asset('resources/vendor/jquery/jquery.form.js')); ?>"></script>
<script>
	function ubahPassword() {
		$.ajax({
			url: "<?php echo e(url($url_admin.'/user/ubahpassword')); ?>",
			type: "POST",
			data: {
				'_token'    		: '<?php echo e(csrf_token()); ?>',
				'id'				: $(`#id`).val(),
				'password_lama'		: $(`#password_lama`).val(),
				'nama'				: $(`#nama`).val(),
				'password'			: $(`#password`).val(),
				'password_confirmation'		: $(`#password_confirmation`).val(),
			},
			beforeSend: function () {
				ojisatrianiLoadingFadeIn();
			},
			success: function (res) {
				ojisatrianiLoadingFadeOut();
				if (res.status === true) {
					Swal.fire({
						title: 'Sukses!',
						text: res.pesan.msg,
						type: 'success',
						timer: 3000
					});
				} else {
					$.each(res.pesan, function(i, item) {
                        $("#"+i).addClass('is-invalid');
                        $("#"+i).after('<div class="invalid-feedback" role="alert">' + item +'</div>');
                    });
					Swal.fire({
						title: 'Whoops!',
						text: res.pesan.msg,
						type: 'info',
						timer: 3000
					});
				}
			}
		});
	}
</script>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('css'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.home.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\master\resources\views/backend/user/ubah_password.blade.php ENDPATH**/ ?>
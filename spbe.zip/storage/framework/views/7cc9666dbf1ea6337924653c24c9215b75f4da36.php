$(document).on('click', 'input[type=checkbox]', function(){
		$(this).siblings('ul')
		.find("input[type='checkbox']")
		.prop('checked', this.checked);
});

var nextUrl=$("#url").val();
		$(document).on("click",".submit-kelola",function() {
		var url					= "<?php echo e(url($url_admin.'/aksesmenu')); ?>";
		var dataString	= $('#frmOji').serializeArray();
		goAjax(url, dataString);
});
<?php /**PATH D:\laragon\www\spbe\resources\views/backend/aksesmenu/ajax.blade.php ENDPATH**/ ?>
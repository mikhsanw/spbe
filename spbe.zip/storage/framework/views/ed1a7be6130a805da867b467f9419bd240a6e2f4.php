$(document).ready(function() {
	$('#datatable').DataTable({
		responsive: true,
		serverside: true,
		lengthChange: true,
		language: {
            url: "<?php echo e(asset('resources/vendor/datatables/js/indonesian.json')); ?>"
        },
		processing: true,
		serverSide: true,
		ajax: "<?php echo e(url($url_admin.'/'.$kode.'/data/'.$id)); ?>",
		columns: [
                { data: 'DT_RowIndex', name: 'DT_RowIndex', orderable: false, searchable: false },
				{ data: 'name' },
				{ data: 'file'},
				{ data: 'action', orderable: false, searchable: false}
		    ]
    });
});
<?php /**PATH D:\laragon\www\new-master\resources\views/backend/upload/datatables_detail.blade.php ENDPATH**/ ?>
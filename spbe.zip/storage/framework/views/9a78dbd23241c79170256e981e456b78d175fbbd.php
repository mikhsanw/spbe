
<?php $__env->startPush('title',ucwords(strtolower($halaman->nama))); ?>
<?php $__env->startPush('header',ucwords(strtolower($halaman->nama))); ?>
<?php $__env->startPush('tombol'); ?>
<button class="waves-effect waves-light btn bg-gradient-primary text-white py-2 px-3 tambah">
	Tambah
</button>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="panel-container show">
	<div class="panel-content">
		<table id="datatable" class="table table-striped table-bordered display" style="width:100%">
			<thead class="bg-primary">
				<tr>
					<th class="width-1">No</th>
					<th class="text-center">Nama</th>
					<th width="50px" class="text-center" tabindex="0" rowspan="1" colspan="1">Aksi</th>
				</tr>
			</thead>
		</table>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<?php echo $__env->make('layouts.backend.js.datatable-js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script type="text/javascript" src="<?php echo e(URL::asset(config('master.aplikasi.author').'/js/'.$halaman->link.'/'.$halaman->kode.'/jquery-crud.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset(config('master.aplikasi.author').'/'.$halaman->kode.'/datatables.js')); ?>"></script>
<script src="<?php echo e(asset('backend/assets/vendor_components/select2/dist/js/select2.full.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.backend.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\spbe\resources\views/backend/foto/index.blade.php ENDPATH**/ ?>
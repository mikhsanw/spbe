<div class="loader-content">
	<div class="d-table">
		<div class="d-table-cell">
			<div class="sk-circle">
				<div class="sk-circle1 sk-child"></div>
				<div class="sk-circle2 sk-child"></div>
				<div class="sk-circle3 sk-child"></div>
				<div class="sk-circle4 sk-child"></div>
				<div class="sk-circle5 sk-child"></div>
				<div class="sk-circle6 sk-child"></div>
				<div class="sk-circle7 sk-child"></div>
				<div class="sk-circle8 sk-child"></div>
				<div class="sk-circle9 sk-child"></div>
				<div class="sk-circle10 sk-child"></div>
				<div class="sk-circle11 sk-child"></div>
				<div class="sk-circle12 sk-child"></div>
			</div>
		</div>
	</div>
</div>


<div class="navbar-area">

	<div class="mobile-nav">
		<?php if($aplikasi->file_logo): ?>
		<a href="<?php echo e(url('/')); ?>" class="logo">
			<img src="<?php echo e(URL::asset($aplikasi->file_logo->url_stream)); ?>" alt="logo">
		</a>
		<?php endif; ?>
	</div>

	<div class="main-nav">
		<div class="container">
			<nav class="navbar navbar-expand-lg navbar-light">
				<?php if($aplikasi->file_logo): ?>
				<a href="<?php echo e(url('/')); ?>" class="navbar-brand">
					<img src="<?php echo e(URL::asset($aplikasi->file_logo->url_stream)); ?>" height="50px" alt="logo">
				</a>
				<?php endif; ?>
				<div class="collapse navbar-collapse mean-menu" id="navbarSupportedContent">
					<ul class="navbar-nav m-auto">
						<?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li class="nav-item">
							<a class="nav-link <?php echo e(is_string($val) ? '' : 'dropdown-toggle'); ?>" href="<?php echo e(is_string($val) ? $val : '#'); ?>"><?php echo e($key); ?></a>
							<?php if(!is_string($val)): ?>
							<ul class="dropdown-menu">
								<?php $__currentLoopData = $val; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keydata => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php echo $__env->make('layouts.frontend.menu',['data'=>$data], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</ul>
							<?php endif; ?>
						</li>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</ul>
				</div>
			</nav>
		</div>
	</div>
</div>
<?php /**PATH D:\laragon\www\spbe\resources\views/layouts/frontend/header.blade.php ENDPATH**/ ?>

<?php $__env->startPush('title','User'); ?>
<?php $__env->startPush('header','User'); ?>
<?php $__env->startPush('tombol'); ?>
<button class="waves-effect waves-light btn bg-gradient-primary text-white py-2 px-3 tambah">
	Tambah
</button>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="panel-container show">
	<div class="panel-content">
		<table id="datatable" class="table table-striped table-bordered display" style="width:100%">
			<thead class="bg-primary">
				<tr>
					<th class="text-center">NIP</th>
					<th >Nama</th>
					<th >E-Mail</th>
					<th class="text-center">Akses Grup</th>
					<th class="text-center">Level</th>
					<th class="text-center wid-10">Aksi</th>
				</tr>
			</thead>
		</table>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<?php echo $__env->make('layouts.backend.js.datatable-js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script type="text/javascript" src="<?php echo e(URL::asset(config('master.aplikasi.author').'/user/jquery.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset(config('master.aplikasi.author').'/user/datatables.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.backend.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\new-master\resources\views/backend/user/index.blade.php ENDPATH**/ ?>
<?php $__currentLoopData = $menu_item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($mn->tampil == 1): ?>
        <?php if($mn->checkAksesmenu(Auth::user()->aksesgrup_id)): ?>
            <?php echo $__env->make('layouts.backend.sidebar_item.submenu', ['mn'=>$mn], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
    <?php else: ?>
        <?php echo $__env->make('layouts.backend.sidebar_item.submenu', ['mn'=>$mn], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH D:\laragon\www\spbe\resources\views/layouts/backend/sidebar_item/menu.blade.php ENDPATH**/ ?>